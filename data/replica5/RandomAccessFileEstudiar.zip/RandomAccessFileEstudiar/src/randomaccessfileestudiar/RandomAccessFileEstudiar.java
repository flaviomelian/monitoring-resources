/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package randomaccessfileestudiar;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Random;

/**
 *
 * @author Flavio
 */
public class RandomAccessFileEstudiar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            var raf = new RandomAccessFile("PERSONAS.dat", "rw");
            //escritura(raf);
            lectura(raf);
            System.out.println("Nota de Alejandro: " + notaDe("Alejandro", raf));
            System.out.println("Media de la clase: " + media(raf));
            raf.close();
        }catch(FileNotFoundException e){
            System.err.println("FICHERO NO DISPONIBLE");
            e.printStackTrace();
        }catch(IOException e){
            System.err.println("ERROR DE ACCESO EN DISCO");
            e.printStackTrace();
        }
    }
    
    private static void escritura(RandomAccessFile raf){
        try{
            var random = new Random();
            String[] personas = {"Sergio", "Laura", "Andres", "Sara", "Alejandro", "Alba", "Rodrigo", "Lara", "Pedro", "Paula", "Alberto"};
            raf.seek(0);
            var escribir = new StringBuffer();
            for(String persona: personas){
                escribir.append(persona);
                escribir.setLength(7);
                raf.writeChars(escribir.toString());
                raf.writeInt(random.nextInt(11));  
                escribir.setLength(0);
            }
        }catch(EOFException e){
            System.out.println("--==**FINAL DEL FICHERO**==--");
        }catch(FileNotFoundException e){
            System.err.println("FICHERO NO DISPONIBLE");
            e.printStackTrace();
        }catch(IOException e){
            System.err.println("ERROR DE ACCESO EN DISCO");
            e.printStackTrace();
        }
    }
    
    private static void lectura(RandomAccessFile raf){
        try{
            raf.seek(0);
            var nombre = "";
            for (var i = 0; i < raf.length() - 11; i++){
                for (var j = 0; j < 7; j++) nombre += raf.readChar();
                System.out.println("Nombre: " + nombre);
                System.out.println("Nota: " + raf.readInt());
                //System.out.println("puntero: " + raf.getFilePointer());
                nombre = "";
            }
        }catch(EOFException e){
            System.out.println("--==**FINAL DEL FICHERO**==--");
        }catch(FileNotFoundException e){
            System.err.println("FICHERO NO DISPONIBLE");
            e.printStackTrace();
        }catch(IOException e){
            System.err.println("ERROR DE ACCESO EN DISCO");
            e.printStackTrace();
        }
    }
    
    private static int notaDe(String nombre, RandomAccessFile raf){
        var nota = 0;
        var nombreBusqueda = new StringBuffer(nombre);
        nombreBusqueda.setLength(7);
        System.out.println("Se busca: " + nombreBusqueda);
        try{
            raf.seek(0);
            var nombreLeido = "";
            for (var i = 0; i < raf.length() - 11; i++){
                for (var j = 0; j < 7; j++) nombreLeido += raf.readChar();
                //nombreLeido.replaceAll(" ", "1");
                //System.out.println("Nombre leido(notaDe()): " + nombreLeido);
                if (nombreLeido.trim().equals(nombreBusqueda.toString())){
                    //System.out.println("randomaccessfileestudiar.RandomAccessFileEstudiar.notaDe() -------LLEGEUE");
                    nota = raf.readInt(); break;
                }
                raf.skipBytes(4);
                nombreLeido = "";
            }
        }catch(FileNotFoundException e){
            System.err.println("FICHERO NO DISPONIBLE");
            e.printStackTrace();
        }catch(EOFException e){
        }catch(IOException e){
            System.err.println("ERROR DE ACCESO EN DISCO");
            e.printStackTrace();
        }
        return nota;
    }
    
    private static double media(RandomAccessFile raf){
        double sumaNotas = 0;
        int alumnos = 0;
        try{
            raf.seek(0);
            for (var i = 0; i < raf.length(); i++){
                raf.skipBytes(7);
                sumaNotas += raf.readInt();
                alumnos++;
                System.out.println(sumaNotas);
            }
        }catch(FileNotFoundException e){
            System.err.println("FICHERO NO DISPONIBLE");
            e.printStackTrace();
        }catch(EOFException e){
            System.out.println("--==**FINAL DEL FICHERO**==--");
        }catch(IOException e){
            System.err.println("ERROR DE ACCESO EN DISCO");
            e.printStackTrace();
        }
        return sumaNotas /= alumnos;
    }
}
