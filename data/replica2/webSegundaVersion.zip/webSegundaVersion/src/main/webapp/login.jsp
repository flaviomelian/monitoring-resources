<%-- 
    Document   : index
    Created on : 24 feb 2024, 19:35:54
    Author     : Flavio
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="datos.GestionAlumnos" %>
<%@page import="datos.GestionAdmins" %>
<%
    var gestion = new GestionAlumnos();
    var gestionAdmins = new GestionAdmins();
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <title>JSP Page</title>
    </head>
    <body>
        <div class="container">
            <form action="alumnos.jsp" method="post">
                <input type="hidden" name="action" value="login"/>
                <div class="row">
                    <div class="col-12">
                        <h1 class="text-center">Login</h1>
                    </div> 
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="name"/>
                </div>
                <div class="mb-3">
                    <label for="passwd" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" name="passwd"/>
                </div>
                <div class="row">
                    <div class="col-12">
                        <input type="submit" class="btn btn-primary but-lg col-12" value="LogIn"/>
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>
