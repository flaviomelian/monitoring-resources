/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package estudiarxml;

import java.io.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.*;
/**
 *
 * @author Flavio
 */
public class EstudiarXML {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            var rand = new Random();
            var fichero = new File("nuevoXML.xml");
            if (!fichero.exists())
                if (fichero.createNewFile())System.out.println("fichero creado");
                else System.out.println("error");
            else System.out.println("fichero ya existente");
            var documento = DocumentBuilderFactory.newInstance().newDocumentBuilder().getDOMImplementation().createDocument(null, "raiz", null);
            escritura(fichero, documento, rand);
            lectura(documento);
            System.out.println("Nota de Sergio: " + notaDe("Sergio", documento));
            System.out.println("Media de la clase: " + media(documento));
            SAXParserFactory.newInstance().newSAXParser().parse(new File("C:\\Users\\Flavio\\Desktop\\nuevoXML.xml"), new Handler("Sergio"));
        }catch(ParserConfigurationException e){
            e.printStackTrace();
        }catch(IOException e){ 
            e.printStackTrace(); e.getMessage();
        }catch(SAXException e){}
    }
    
    private static void escritura(File fichero, Document documento, Random rand){
        try{
            var personas = documento.createElement("personas");
            documento.getDocumentElement().appendChild(personas);
            String[] nombres = {"Lolo", "Lara", "Laura", "Sergio", "Jose", "Eduardo"};
            for (var i = 0; i < 20; i++) addChild(documento, personas, "persona", nombres[rand.nextInt(nombres.length)], "nota", rand.nextInt(11));
            var serializarXml = new XMLSerializer(new FileOutputStream(fichero), new OutputFormat(documento));
            serializarXml.serialize(documento);
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    private static void addChild(Document documento, Element personas, String etiquetaNombre, String valorNombre, String etiquetaNota, int valorNota){
        var persona = documento.createElement(etiquetaNombre);
        var nombreEtiqueta = documento.createElement("nombre");
        var nombre = documento.createTextNode(valorNombre);
        nombreEtiqueta.appendChild(nombre);
        var nota = documento.createElement(etiquetaNota);
        var puntuacion = documento.createTextNode(valorNota + "");
        nota.appendChild(puntuacion);
        persona.appendChild(nombreEtiqueta);
        persona.appendChild(nota);
        personas.appendChild(persona);
    }
    
    /*private static void lectura(Document documento) throws SAXException{
        try{
            var lector = XMLReaderFactory.createXMLReader();
            var manejo = new Manejo();
            lector.setContentHandler(manejo);
        }catch(IOException e | SAXException ex){
            
        }
    }*/
    
    private static void lectura(Document documento) {        
        var listaPersonas = documento.getElementsByTagName("persona");
        for (var i = 0; i < listaPersonas.getLength(); i++) {            
            var persona = listaPersonas.item(i);
            System.out.println("Persona nº " + (i + 1));            
            var nombre = ((Element) persona).getElementsByTagName("nombre").item(0);
            var nota = ((Element) persona).getElementsByTagName("nota").item(0);            
            System.out.println("Nombre: " + nombre.getFirstChild().getNodeValue().trim());
            System.out.println("Nota: " + nota.getFirstChild().getNodeValue().trim() + "\n");        
        }
    }
    
    private static int notaDe(String nombre, Document documento){
        var nota = 0;
        var listaPersonas = documento.getElementsByTagName("persona");
        for (var i = 0; i < listaPersonas.getLength(); i++){
            System.out.println(((Element)listaPersonas.item(i)).getElementsByTagName("nombre").item(0).getFirstChild().getNodeValue());
            if (((Element)listaPersonas.item(i)).getElementsByTagName("nombre").item(0).getFirstChild().getNodeValue().equals(nombre)){
                nota = Integer.parseInt(((Element)listaPersonas.item(i)).getElementsByTagName("nota").item(0).getFirstChild().getNodeValue());
                System.out.println("---UYEKITA---"); break;
            }
        }
        return nota;
    }
    
    private static double media(Document documento){
        var suma = 0;
        var listaPersonas = documento.getFirstChild().getChildNodes();
        for (var i = 0; i < listaPersonas.getLength(); i++){
            suma += Integer.parseInt(((Element)listaPersonas.item(i)).getElementsByTagName("nota").item(0).getFirstChild().getNodeValue());
        }
        return suma / listaPersonas.getLength();
    }
}


class Handler extends DefaultHandler{
    
    private int spaces, elements;
    private String dato, nombre;
    private int suma, personas;
    private boolean find, esNota, found;
    
    public Handler(String nombre){
        super();
        this.spaces = 0;
        this.elements = 2;
        this.dato = "";
        this.nombre = nombre;
        this.suma = 0;
        this.personas = 0;
        this.find = false;
        this.esNota = false;
        this.found = false;
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        // Este método se llama cuando se encuentra el inicio de un elemento
        for (var i = 0; i < this.spaces; i++) System.out.print("\t");
        if (qName.equals("nota")) this.esNota = true;
        else if (qName.equals("persona")) this.personas++;
        System.out.println("<" + qName + ">"); this.spaces++;
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // Este método se llama cuando se encuentran caracteres dentro de un elemento
        for (var i = 0; i < this.spaces; i++) System.out.print("\t");
        var caracteres = new String(ch, start, length).trim();
        if (caracteres.equals(this.nombre)) this.find = true;
        if (this.found) this.find = false;
        if (this.esNota){
            this.dato = caracteres; this.found = true; this.esNota = false; //System.out.println("AAA    " + caracteres + "    BBB");//this.suma += Integer.parseInt(this.dato);
        }
        //this.suma += Integer.parseInt(this.dato);
        System.out.println(caracteres); this.spaces--;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // Este método se llama cuando se encuentra el final de un elemento
        if (qName.equals("personas") || qName.equals("raiz")) this.spaces--; 
        for (var i = 0; i < this.spaces; i++) System.out.print("\t");
        System.out.println("</" + qName + ">"); this.elements--;
        if (qName.equals("raiz")){
            notaDe(); //System.out.println("Media: " + this.suma / this.personas);
        }
        if (this.elements == 0){
            this.spaces--; this.elements = 3;
        }
    }
    
    public void notaDe(){
        System.out.println("Nota de " + this.nombre + ": " + this.dato);
    }
}
    
    