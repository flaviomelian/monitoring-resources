/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import conexiones.MiConexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Flavio
 */
public class GestionAlumnos {
    
    private MiConexion conexion;
    private Connection con;

    public GestionAlumnos() throws ClassNotFoundException, SQLException {
        this.conexion = new MiConexion();
        this.con = this.conexion.getConexion();
    }
    
    public boolean insertarAlumno(String nombre, String apellidos, int edad, int nota, String direccion, int curso, String datosFamilia, boolean foto){
        boolean insercion = true;
        try {
            var entradaSql = this.con.prepareStatement("insert into alumno(nombre, apellidos, edad, nota, direccion, curso, foto, datos_familia) values (?, ?, ?, ?, ?, ?, ?, ?);");
            entradaSql.setString(1, nombre);
            entradaSql.setString(2, apellidos);
            entradaSql.setInt(3, edad);
            entradaSql.setInt(4, nota);
            entradaSql.setString(5, direccion);
            entradaSql.setInt(6, curso);
            entradaSql.setBoolean(7, foto);
            entradaSql.setString(8, datosFamilia);
            insercion = entradaSql.execute();
        } catch (SQLException ex) {
            insercion = false;
            Logger.getLogger(GestionAlumnos.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            return insercion;
        }
    }
    
    public boolean actualizarAlumno(String nombre, String apellidos, int edad, int nota, String direccion, int curso, String datosFamilia, boolean foto, int id){
        boolean actualizacion = true;
        try {
            var entradaSql = this.con.prepareStatement(
                    "update alumno set nombre = ?,"
                  + " apellidos = ?, edad = ?,"
                  + " nota = ?, direccion = ?, curso = ?,"
                  + " datos_familia = ?, foto = ? where id= ?;");
            entradaSql.setString(1, nombre);
            entradaSql.setString(2, apellidos);
            entradaSql.setInt(3, edad);
            entradaSql.setInt(4, nota);
            entradaSql.setString(5, direccion);
            entradaSql.setInt(6, curso);
            entradaSql.setInt(7, id);
            actualizacion = entradaSql.execute();
        } catch (SQLException ex) {
            actualizacion = false;
            Logger.getLogger(GestionAlumnos.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            return actualizacion;
        }
    }
    
    public boolean eliminarAlumno(int id){
        boolean eliminado = true;
        try {
            var entradaSql = this.con.prepareStatement("delete from alumno where id = ?");
            entradaSql.setInt(1, id);
            eliminado = entradaSql.execute();
        } catch (SQLException ex) {
            eliminado = false;
            Logger.getLogger(GestionAlumnos.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            return eliminado;
        }
    }
    
    public Alumno getAlumno(int id){
        Alumno alumno = null;
        try {
            var entradaSql = this.con.prepareStatement("select * from alumno where id = ?;");
            entradaSql.setInt(1, id);
            var resultSet = entradaSql.executeQuery();
            alumno = new Alumno(resultSet.getInt(1), 
                                resultSet.getString(2), 
                                resultSet.getString(3), 
                                resultSet.getString(4), 
                                resultSet.getInt(5), 
                                resultSet.getString(6),
                                resultSet.getInt(7), 
                                resultSet.getString(8), 
                                resultSet.getBoolean(9));
        } catch (SQLException ex) {
            Logger.getLogger(GestionAlumnos.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            return alumno;
        }
    }
    
    public ArrayList<Alumno> getAlumnos() throws SQLException{
        var alumnos = new ArrayList<Alumno>();
        var consulta = this.con.prepareStatement("select * from alumno;");
        var resultSet = consulta.executeQuery();
        while(resultSet.next())
            alumnos.add(new Alumno(resultSet.getInt("id"), 
                    resultSet.getString("nombre"), 
                    resultSet.getString("apellidos"), 
                    String.valueOf(resultSet.getInt("curso")), 
                    resultSet.getInt("nota"),
                    resultSet.getString("direccion"),
                    resultSet.getInt("edad"),
                    resultSet.getString("datos_familia"),
                    resultSet.getBoolean("foto")));
        return alumnos;
    }
    
}
