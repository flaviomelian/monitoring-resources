/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;
import conexiones.*;
import java.sql.Connection;
import java.sql.SQLException;
/**
 *
 * @author Flavio
 */
public class GestionAdmins {
    
    private MiConexion conexion;
    private Connection con;
    
    public GestionAdmins() throws ClassNotFoundException, SQLException{
        this.conexion = new MiConexion();
        this.con = this.conexion.getConexion();
    }
    
    public boolean comprobarContraseña(String nombre, String passwd) throws SQLException{
        var id = -1;
        var consulta = this.con.prepareStatement("select * from admins;");
        var resultSet = consulta.executeQuery();
        while(resultSet.next())
            if (resultSet.getString("nombre").equals(nombre) && resultSet.getString("passwd").equals(passwd)) return true;
        return false;
    }
    
}
