<%-- 
    Document   : alumnos
    Created on : 25 feb 2024, 14:09:43
    Author     : Flavio
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="datos.*" %>
<%@page import="conexiones.*" %>
<%
    var gestion = new GestionAlumnos();
    var gestionAdmins = new GestionAdmins();
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <title>Gestión de Alumnos IES El Rincón</title>
    </head>
    <body>
        <%
            var action = request.getParameter("action");
            session = request.getSession(true);
            var sessionId = session.getAttribute("id");
            
            var id = 0;
            var nombre = "";
            var apellidos = "";
            var edad = 0;
            var direccion = "";
            var curso = 0;
            var nota = 0;
            var datosFamilia = "";
            var permisoFoto = false;
            
            if (action != null){
                if (!gestionAdmins.comprobarContraseña(request.getParameter("name"), request.getParameter("passwd"))) response.sendRedirect("login.jsp");
                 switch(action){
                    case "insertar":
                        nombre = request.getParameter("name");
                        apellidos = request.getParameter("lastName");
                        edad = Integer.parseInt(request.getParameter("edad"));
                        direccion = request.getParameter("direccion");
                        curso = Integer.parseInt(request.getParameter("curso"));
                        nota = Integer.parseInt(request.getParameter("nota"));
                        datosFamilia = request.getParameter("datosFamilia");
                        permisoFoto = "concedido".equals(request.getParameter("foto"));
                        gestion.insertarAlumno(nombre, apellidos, edad, nota, direccion, curso, datosFamilia, permisoFoto);
                        break;
                    case "editar":
                        id = Integer.parseInt(request.getParameter("id"));
                        nombre = request.getParameter("name");
                        apellidos = request.getParameter("lastName");
                        edad = Integer.parseInt(request.getParameter("edad"));
                        direccion = request.getParameter("direccion");
                        curso = Integer.parseInt(request.getParameter("curso"));
                        nota = Integer.parseInt(request.getParameter("nota"));
                        datosFamilia = request.getParameter("datosFamilia");
                        permisoFoto = "concedido".equals(request.getParameter("foto"));
                        gestion.actualizarAlumno(nombre, apellidos, edad, nota, direccion, curso, datosFamilia, permisoFoto, id);
                        break;
                    case "eliminar":
                        id = Integer.parseInt(request.getParameter("id"));
                        gestion.eliminarAlumno(id);
                        break;
                }
            }
        %>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="text-center">Gestión de alumnos - IES El Rincón</h1>
                    <a href="login.jsp?action=logout">LogOut</a>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <%
                        var alumnos = gestion.getAlumnos();
                    %>
                    <table class="table table-stripped">
                        <thead>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Apellidos</th>
                            <th>Curso</th>
                            <th>Nota</th>
                            <th>Dirección</th>
                            <th>Edad</th>
                            <th>Datos de la familia</th>
                            <th>Foto</th>
                        </thead>
                        <tbody>
                            <%
                                for(Alumno alumno: alumnos){
                            %>
                            <tr>
                                <td><%=alumno.getId()%></td>
                                <td><%=alumno.getNombre()%></td>
                                <td><%=alumno.getApellidos()%></td> 
                                <td><%=alumno.getCurso()%></td>
                                <td><%=alumno.getNota()%></td>
                                <td><%=alumno.getDireccion()%></td> 
                                <td><%=alumno.getEdad()%></td>
                                <td><%=alumno.getDatosFamilia()%></td>
                                <td><input class="form-check-input" type="checkbox" id="flexCheckDefault" disabled <%if (alumno.isPermisoFoto()){%> <%="checked"%> <%}%></td>
                                <td>
                                    <form action="insertar.jsp" method="post">
                                        <input type="hidden" name="action" value="editar">
                                        <input type="hidden" name="id" value="<%alumno.getId();%>">
                                        <input type="submit" value="Editar" class="btn btn-warning">
                                    </form>
                                </td>
                                <td>
                                    <form action="alumnos.jsp" method="post">
                                        <input type="hidden" name="action" value="eliminar">
                                        <input type="hidden" name="id" value="<%alumno.getId();%>">
                                        <input type="submit" value="Eliminar" class="btn btn-danger">
                                    </form>
                                </td>
                            </tr>
                            <%
                                }
                            %>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <form action="insertar.jsp" method="post">
                        <input type="hidden" name="action" value="insertar">
                        <input type="submit" value="Insertar" class="btn btn-success btn-log col-12">
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>
