package com.flavio.replica_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReplicaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReplicaServiceApplication.class, args);
	}

}
