package com.flavio.replica_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReplicaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
