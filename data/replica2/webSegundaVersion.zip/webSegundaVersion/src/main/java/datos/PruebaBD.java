/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import java.sql.SQLException;
import java.util.Random;

/**
 *
 * @author Flavio
 */
public class PruebaBD {
    
    public static void main(String[] args){
        /*try{
            /*var random = new Random();
            var gestion = new GestionAlumnos();
            String[] nombre = {"Alvaro", "Sergio", "Lara", "Samel", "Alexandra"};
            String[] apellido = {"Gutierrez", "Santana", "Melian", "Garcia", "Almeida"};
            String[] direcciones = {"Calle las acacias", "Calle las almendras", "Calle los olivos", "Calle los lirios", "Calle Miguel Angel Blanco"};
            for (var i = 0; i < 10; i++) 
                System.out.println(gestion.insertarAlumno(nombre[random.nextInt(nombre.length)],
                        apellido[random.nextInt(apellido.length)],
                        random.nextInt(18, 30),
                        direcciones[random.nextInt(direcciones.length)],
                        random.nextInt(1, 2),
                        "Padre: " + numeroTLF(random) + " Madre: " + numeroTLF(random)));
            for(var i = 0; i < 10; i++) System.out.println(gestion.getAlumno(i + 1));
        }catch(ClassNotFoundException e){
            e.printStackTrace();
        }catch(SQLException e){
            e.printStackTrace();
        }*/
    }
    
    private static String numeroTLF(Random random){
        var numero = "" + random.nextInt(6, 1);
        for (var i = 0; i < 8; i++) numero += random.nextInt(9);
        return numero;
    }
    
}
