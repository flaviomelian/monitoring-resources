
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author David
 */
public class InformacionCliente extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGeneric(req, resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        doGeneric(req, resp);
    }

    protected void doGeneric(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
            out.println("<body>");
                out.println("<ul>");
                    out.println("<li> <b>Método:</b> "+req.getMethod()+ " </li>");
                    out.println("<li> <b>IP Cliente:</b> "+ req.getRemoteAddr() +" </li>");
                    out.println("<li> <b>IP Servidor:</b> "+ req.getLocalAddr()+ " </li>");
                    out.println("<li> <b>Puerto:</b> "+ req.getRemotePort()+" </li>");
                out.println("</ul>");
            out.println("</body>");
        out.println("</html>");
        out.close();
    }

}
