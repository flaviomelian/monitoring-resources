<%-- 
    Document   : insertar
    Created on : 24 feb 2024, 19:36:11
    Author     : Flavio
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="datos.*" %>
<%@page import="conexiones.*" %>
<%
    var gestion = new GestionAlumnos();
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <title>JSP Page</title>
    </head>
    <body>
        <div class="container">
            <form action="alumnos.jsp" method="post">
                <%if (request.getParameter("action").equals("insertar")){%>
                <div class="row">
                    <div class="col-12">
                        <h1 class="text-center">Insertar alumno</h1>
                    </div>
                </div>
                <%}else{%>
                <div class="row">
                    <div class="col-12">
                        <h1 class="text-center">Editar alumno</h1>
                    </div>
                </div><%}%>
                <div class="mb-3">
                    <label for="name" class="form-label">Nombre del alumno</label>
                    <input type="text" class="form-control" name="name">
                </div> 
                <div class="mb-3">
                    <label for="surname" class="form-label">Apellidos del alumno</label>
                    <input type="text" class="form-control" name="surname">
                </div> 
                <div class="mb-3">
                    <label for="age" class="form-label">Edad del alumno</label>
                    <input type="text" class="form-control" name="age">
                </div> 
                <div class="mb-3">
                    <label for="direccion" class="form-label">Direccion del alumno</label>
                    <input type="text" class="form-control" name="direccion">
                </div> 
                <div class="mb-3">
                    <label for="curso" class="form-label">Curso del alumno</label>
                    <input type="text" class="form-control" name="curso">
                </div> 
                <div class="mb-3">
                    <label for="nota" class="form-label">Nota del alumno</label>
                    <input type="text" class="form-control" name="nota">
                </div> 
                <div class="mb-3">
                    <label for="datosFamilia" class="form-label">Datos de la familia</label>
                    <textarea class="form-control" name="datosFamilia" rows="3"></textarea>
                </div> 
                <input class="form-check-input" type="checkbox" value="concedido" name="foto">
                <label class="form-check-label" for="flexCheckDefault">Consentimiento para uso de foto</label>
                <br/><br/><br/>
                <div class="row">
                    <div class="col-12">
                        <%if (request.getParameter("action").equals("insertar")){%>
                        <input type="submit" class="btn btn-success btn-lg col-12" value="Insertar"/>
                        <%}else{%>
                        <input type="submit" class="btn btn-success btn-lg col-12" value="Editar"/>
                        <%}%>
                    </div>
                </div>
            </form>
        </div>            
    </body>
</html>
